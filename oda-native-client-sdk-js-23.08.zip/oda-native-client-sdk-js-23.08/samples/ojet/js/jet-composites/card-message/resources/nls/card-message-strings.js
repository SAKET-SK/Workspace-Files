/**
  Copyright (c) 2015, 2021, Oracle and/or its affiliates.
  Licensed under The Universal Permissive License (UPL), Version 1.0
  as shown at https://oss.oracle.com/licenses/upl/

*/
define({
  "root": {
    "card-message" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
  }
});