module.exports = {
  components: [
    './components'
  ]
};